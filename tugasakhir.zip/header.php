	<header>
		<h1 class="judul">Patrick Budianto</h1>
	</header>
	<body>
		<h1>SELAMAT DATANG DI TOKO MIRACLE STORE</h1>
	</body>
	<link rel="stylesheet" type="text/css" href="style1.css">