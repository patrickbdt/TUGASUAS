<?php 
include('head.php');
include('header.php');
include('nav.php');
 ?>